#!/usr/bin/env python3
"""Step 4-F0 runner: F0-C0 / F0-I / F0-D x 80 epochs (seed 20260812).

Model = Step4F0Model (RGB frozen anchor + 2ch aux pyramid encoder + zero-init 1x1
residual injection at P3/P4/P5 + original neck/head). The 6ch TriModalDataset and
the float32 no-/255 trainer/validator contract are REUSED from the fixed Step-3
runner; the model splits the 6ch batch internally (aux_mode zero/ir/depth).

Freeze profile (F0): RGB backbone frozen (BN eval enforced on model.train());
trainable = aux encoder + fusion projections + neck/head.
Recipe: R3-causal-earlyfusion-sample (unchanged). Growth log records per-scale
fusion projection norms + aux encoder norm (F0-C0 must stay exactly 0).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from multimodal import modality_preprocess as mp  # noqa: E402
from multimodal.early_fusion_yolo26 import MODEL_INIT_SEED, build_reference_3ch  # noqa: E402
from multimodal.raw_sample_index import OUT_DEFAULT  # noqa: E402
from multimodal.step4_f0_model import Step4F0Model  # noqa: E402
from multimodal.trimodal_dataset import TriModalDataset  # noqa: E402
from ultralytics.data.build import InfiniteDataLoader  # noqa: E402
from ultralytics.models.yolo.detect.train import DetectionTrainer  # noqa: E402
from ultralytics.models.yolo.detect.val import DetectionValidator  # noqa: E402

GROUPS = {"F0-C0": "zero", "F0-I": "ir", "F0-D": "depth"}
DATASET_GROUP = {"F0-C0": "C0-N", "F0-I": "C1-I", "F0-D": "C2-D"}  # same 6ch content contract

R3_KW = dict(
    epochs=80, batch=4, nbs=4, warmup_epochs=0, workers=0, cache=False,
    imgsz=640, max_det=100, patience=100, close_mosaic=0,
    mosaic=0.0, mixup=0.0, cutmix=0.0, copy_paste=0.0,
    scale=0.0, translate=0.0, degrees=0.0, shear=0.0, perspective=0.0,
    multi_scale=0.0, amp=False, fliplr=0.30393, flipud=0.0,
    # amp=False is F0-FROZEN: AMP-path incompatibility / projection-update suppression
    # (exact mechanism UNRESOLVED, non-blocking). Measured with otherwise-identical
    # Trainer conditions: amp=True -> zero-init projections stayed EXACTLY 0 for a full
    # epoch; amp=False -> P3/P4/P5 projections updated normally. Possible mechanisms
    # (autocast backward numerics, GradScaler behavior / step skipping, or interaction
    # with zero-init + MuSGD) are not pursued further this stage.
    hsv_h=0.0, hsv_s=0.0, hsv_v=0.0, bgr=0.0,
    auto_augment=None, erasing=0.0,
    seed=20260812, deterministic=True, end2end=False,
    plots=False, cls_pw=0.0,
    optimizer="MuSGD", lr0=0.00038, lrf=0.88219, momentum=0.94751,
    weight_decay=0.00027, box=9.83241, cls=0.64896, dfl=0.95824,
)


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_json(obj) -> str:
    payload = json.dumps(obj, ensure_ascii=False, separators=(",", ":"), sort_keys=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class Step4Validator(DetectionValidator):
    """Float 6ch validator (no /255); the F0 model splits the 6ch batch internally."""

    def preprocess(self, batch):
        for k, v in batch.items():
            if isinstance(v, torch.Tensor):
                batch[k] = v.to(self.device, non_blocking=self.device.type == "cuda")
        batch["img"] = batch["img"].half() if self.args.half else batch["img"].float()
        return batch


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--group", choices=["F0-C0", "F0-I", "F0-D"], required=True)
    p.add_argument("--project", default="runs/step4_f0")
    p.add_argument("--name", default=None)
    p.add_argument("--run-kind", choices=["smoke", "formal", "recovery"], default="formal")
    p.add_argument("--contract", default=OUT_DEFAULT)
    p.add_argument("--device", default="0")
    p.add_argument("--seed", type=int, default=20260812)
    p.add_argument("--epochs", type=int, default=80)
    p.add_argument("--batch", type=int, default=4)
    a = p.parse_args()

    if a.run_kind == "smoke" and a.name is None:
        a.name = f"smoke-{a.group}-e{a.epochs}"
    elif a.name is None:
        a.name = a.group
    project = Path(a.project).resolve()
    run_dir = project / a.name
    if a.run_kind in {"formal", "recovery"} and run_dir.exists():
        raise RuntimeError(f"FORMAL_RUN_DIR_EXISTS: {run_dir}")

    contract = json.loads(Path(a.contract).read_text(encoding="utf-8"))

    # reproducible aux-encoder init (RGB path is pretrained; aux encoder is new)
    rng_state = torch.random.get_rng_state()
    torch.manual_seed(MODEL_INIT_SEED)
    model = Step4F0Model(build_reference_3ch(), aux_mode=GROUPS[a.group])
    torch.random.set_rng_state(rng_state)
    model.nc = 12

    requested_batch = int(a.batch)
    trace_path = run_dir / "step4_g8_trace.jsonl"
    growth_path = run_dir / "step4_growth.jsonl"

    class Step4Trainer(DetectionTrainer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.step4_group = a.group
            self.step4_contract = contract
            self.step4_requested_batch = requested_batch
            self._epoch_dataset = None
            self._g8_actual_ids: list[str] = []
            self._g8_actual_flips: list[bool] = []

        def build_dataset(self, img_path, mode="train", batch=None):
            split = "train" if mode == "train" else "val"
            return TriModalDataset(self.step4_contract, split=split,
                                   group=DATASET_GROUP[self.step4_group],
                                   imgsz=self.args.imgsz, seed=self.args.seed,
                                   fliplr=self.args.fliplr, augment=(mode == "train"))

        def get_dataloader(self, dataset_path, batch_size=16, rank=0, mode="train"):
            if mode == "train":
                dataset = self.build_dataset(dataset_path, mode, batch_size)
                self._epoch_dataset = dataset
                return InfiniteDataLoader(
                    dataset, batch_size=batch_size, sampler=dataset.sampler,
                    shuffle=False, num_workers=self.args.workers,
                    collate_fn=dataset.collate_fn, pin_memory=True, drop_last=False)
            return super().get_dataloader(dataset_path, batch_size, rank, mode)

        def preprocess_batch(self, batch):
            if int(self.args.batch) != self.step4_requested_batch:
                raise RuntimeError("ABORT_RESOURCE_PROFILE_CHANGED")
            # ACTUAL DataLoader yield evidence (before any device copy), same as the
            # fixed Step-3 runner — no planned-hash-only regression (reviewer P0-3).
            ids = batch.get("sample_id")
            flips = batch.get("flip_applied")
            if ids is not None:
                self._g8_actual_ids.extend(str(x) for x in ids)
            if flips is not None:
                self._g8_actual_flips.extend(bool(x) for x in flips)
            for k, v in batch.items():
                if isinstance(v, torch.Tensor):
                    batch[k] = v.to(self.device, non_blocking=self.device.type == "cuda")
            batch["img"] = batch["img"].half() if self.args.half else batch["img"].float()
            return batch

        def _build_train_pipeline(self):
            # Reviewer P0: stock _setup_train re-enables requires_grad on non-stock
            # freeze-pattern params (our names are rgb_backbone.*, freeze: null).
            # Re-freeze AFTER the unfreeze loop and BEFORE the optimizer is built.
            from multimodal.trainability import freeze_module
            freeze_module(self.model.rgb_backbone, freeze_bn_stats=True)
            super()._build_train_pipeline()
            # G5 hard gate: optimizer membership + frozen anchor (reviewer-mandated)
            opt_ids = {id(p) for grp in self.optimizer.param_groups for p in grp["params"]}
            missing = []
            for name, module in (("fusions", self.model.fusions),
                                 ("aux_encoder", self.model.aux_encoder),
                                 ("tail", self.model.tail)):
                for p in module.parameters():
                    if not p.requires_grad or id(p) not in opt_ids:
                        missing.append(name)
            frozen_violation = any(p.requires_grad for p in
                                   self.model.rgb_backbone.parameters())
            if missing or frozen_violation:
                raise RuntimeError(
                    f"G5_OPTIMIZER_MEMBERSHIP_FAIL: missing={sorted(set(missing))} "
                    f"rgb_trainable={frozen_violation}")
            print(f"[{a.group}] G5 optimizer membership PASS: "
                  f"fusions+aux+tail in optimizer, RGB frozen")

        def get_validator(self):
            v = Step4Validator(self.test_loader, save_dir=self.save_dir, args=self.args)
            return v

        def final_eval(self):
            print(f"[{a.group}] final_eval skipped (post-hoc eval_step4_causality)")

    kw = dict(R3_KW)
    kw.update(epochs=a.epochs, batch=a.batch, seed=a.seed, project=str(project),
              name=a.name, device=a.device,
              data="D:/pycharm/Python Develop/YOLO_1/v031_step1_rgb_sample/dataset.yaml",
              exist_ok=True, model="yolo26s.yaml")
    trainer = Step4Trainer(overrides=kw)
    trainer.model = model
    trainer.model.args = trainer.args

    trace = []
    growth = []

    def on_epoch_start(tr):
        ds = getattr(tr, "_epoch_dataset", None)
        if ds is None:
            raise RuntimeError("G8_NO_EPOCH_DATASET")
        ds.set_epoch(tr.epoch)
        if hasattr(tr.train_loader, "reset"):
            tr.train_loader.reset()  # InfiniteDataLoader owns a persistent iterator
        tr._g8_actual_ids = []
        tr._g8_actual_flips = []

    def on_epoch_end(tr):
        ds = tr._epoch_dataset
        expected_ids = [ds.ids[i] for i in ds.sampler.perm]
        expected_flips = [mp.should_flip(ds.seed, tr.epoch, sid, ds.fliplr)
                          for sid in expected_ids]
        actual_ids = list(tr._g8_actual_ids)
        actual_flips = list(tr._g8_actual_flips)
        if actual_ids != expected_ids:
            raise RuntimeError(f"G8_ACTUAL_ORDER_MISMATCH epoch={tr.epoch}")
        if actual_flips != expected_flips:
            raise RuntimeError(f"G8_ACTUAL_FLIP_MISMATCH epoch={tr.epoch}")
        legacy_flip_bits = "".join("1" if f else "0" for f in expected_flips)
        trace.append({"epoch": tr.epoch,
                      "n_samples": len(actual_ids),
                      "sample_order_sha256": ds.sampler.order_sha256(),
                      "flip_schedule_sha256": sha256_text(legacy_flip_bits),
                      "expected_order_sha256": sha256_json(expected_ids),
                      "actual_order_sha256": sha256_json(actual_ids),
                      "expected_flip_sha256": sha256_json(expected_flips),
                      "actual_flip_sha256": sha256_json(actual_flips),
                      "actual_matches_expected": True,
                      "batch": int(tr.args.batch)})
        w = tr.model.fusions
        growth.append({"epoch": tr.epoch + 1,
                       "projP3_norm": float(w["4"].proj.weight.norm()),
                       "projP4_norm": float(w["6"].proj.weight.norm()),
                       "projP5_norm": float(w["10"].proj.weight.norm()),
                       "aux_encoder_norm": float(sum(p.norm() for p in
                                                      tr.model.aux_encoder.parameters())),
                       "batch": int(tr.args.batch)})

    trainer.add_callback("on_train_epoch_start", on_epoch_start)
    trainer.add_callback("on_train_epoch_end", on_epoch_end)

    run_dir.mkdir(parents=True, exist_ok=True)

    def _state_sha(module) -> str:
        h = hashlib.sha256()
        for n, p in sorted(module.state_dict().items()):
            h.update(n.encode())
            h.update(p.detach().cpu().contiguous().numpy().tobytes())
        return h.hexdigest()

    def _param_sha(module) -> str:
        h = hashlib.sha256()
        for n, p in sorted(module.named_parameters()):
            h.update(n.encode())
            h.update(p.detach().cpu().contiguous().numpy().tobytes())
        return h.hexdigest()

    manifest = {
        "schema": "step4-f0-manifest-v1",
        "group": a.group,
        "physical_run_name": a.name,
        "run_kind": a.run_kind,
        "model": "Step4F0Model (RGB anchor + zero-init residual)",
        "aux_mode": GROUPS[a.group],
        "freeze": "RGB backbone frozen, BN eval",
        "recipe": "R3-causal-earlyfusion-sample",
        "expected_epochs": a.epochs,
        "requested_batch": a.batch,
        "seed": a.seed,
        "aux_encoder_seed": MODEL_INIT_SEED,
        "contract_sha256": hashlib.sha256(Path(a.contract).read_bytes()).hexdigest(),
        "initial_rgb_backbone_sha256": _state_sha(model.rgb_backbone),
        "initial_aux_encoder_sha256": _state_sha(model.aux_encoder),
        "initial_aux_encoder_param_sha256": _param_sha(model.aux_encoder),
        "initial_fusion_sha256": _state_sha(model.fusions),
        "initial_model_state_sha256": _state_sha(model),
        "g8_evidence": "actual_dataloader_yield_v1",
        "ultralytics_version": __import__("ultralytics").__version__,
        "created_at": __import__("datetime").datetime.now().astimezone().isoformat(),
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False),
                                           encoding="utf-8")

    trainer.train()

    (run_dir / "step4_g8_trace.jsonl").write_text(
        "\n".join(json.dumps(t) for t in trace) + "\n", encoding="utf-8")
    (run_dir / "step4_growth.jsonl").write_text(
        "\n".join(json.dumps(g) for g in growth) + "\n", encoding="utf-8")

    # ---- G6: REAL optimizer-update gate (reviewer-mandated hard evidence) ----
    # Uses the IN-MEMORY fp32 trained model (trainer.model): the saved EMA checkpoint
    # is half precision, where tiny bias updates (~1e-5) underflow to exact 0 — that
    # would falsely report "bias never moved" for F0-C0.
    # aux/fusions compare PARAMETERS only: train-mode BN running stats legitimately
    # drift even for zero input (C0), which is not a parameter update.
    trained = trainer.model

    def _state_sha(module) -> str:
        h = hashlib.sha256()
        for n, p in sorted(module.state_dict().items()):
            h.update(n.encode())
            h.update(p.detach().cpu().contiguous().numpy().tobytes())
        return h.hexdigest()

    def _param_sha(module) -> str:
        h = hashlib.sha256()
        for n, p in sorted(module.named_parameters()):
            h.update(n.encode())
            h.update(p.detach().cpu().contiguous().numpy().tobytes())
        return h.hexdigest()

    # Rebuild the deterministic initial aux encoder for a tolerance-based comparison:
    # with weight_decay>0, SGD shrinks zero-grad params by ~(1 - lr*wd) per step
    # (~1e-7/step), so C0's "aux unchanged" can only be checked within that scale.
    _rng = torch.random.get_rng_state()
    torch.manual_seed(MODEL_INIT_SEED)
    _initial_model = Step4F0Model(build_reference_3ch(), aux_mode=GROUPS[a.group])
    torch.random.set_rng_state(_rng)

    def _param_rel_diff(module_a, module_b) -> float:
        max_rel = 0.0
        for (_, p), (_, q) in zip(sorted(module_a.named_parameters()),
                                  sorted(module_b.named_parameters())):
            p = p.detach().cpu()
            q = q.detach().cpu()
            rel = ((p - q).abs() / (q.abs() + 1e-12)).max().item()
            max_rel = max(max_rel, rel)
        return max_rel

    aux_rel = _param_rel_diff(trained.aux_encoder, _initial_model.aux_encoder)
    # P1 (reviewer): elementwise max_rel explodes when any initial param is ~0; record
    # stable global metrics alongside (max_rel kept as diagnostic only).
    def _param_global_diffs(module_a, module_b):
        l2_num, l2_den, max_abs = 0.0, 0.0, 0.0
        for (_, p), (_, q) in zip(sorted(module_a.named_parameters()),
                                  sorted(module_b.named_parameters())):
            p = p.detach().cpu().float()
            q = q.detach().cpu().float()
            l2_num += float((p - q).pow(2).sum())
            l2_den += float(q.pow(2).sum())
            max_abs = max(max_abs, float((p - q).abs().max()))
        return {"global_rel_l2": (l2_num ** 0.5) / (l2_den ** 0.5 + 1e-12),
                "max_abs_change": max_abs}

    aux_glob = _param_global_diffs(trained.aux_encoder, _initial_model.aux_encoder)
    gate = {
        "rgb_backbone_unchanged": _state_sha(trained.rgb_backbone) ==
                                  manifest["initial_rgb_backbone_sha256"],
        "aux_encoder_max_rel_change_diagnostic": aux_rel,
        "aux_encoder_global_rel_l2": aux_glob["global_rel_l2"],
        "aux_encoder_max_abs_change": aux_glob["max_abs_change"],
        "proj_weight_norms": [float(trained.fusions[k].proj.weight.norm())
                              for k in ("4", "6", "10")],
        "proj_bias_max": [float(trained.fusions[k].proj.bias.abs().max())
                          for k in ("4", "6", "10")],
    }
    if a.group == "F0-C0":
        # 80-epoch decay scale: momentum-amplified weight decay on zero-grad params
        # accumulates velocity ~ lr*wd/(1-momentum) ~ 2e-6/step -> ~4.8e-4 rel over
        # 240 steps (measured 2.0e-4 global_rel_l2, 4.1e-4 max_rel diagnostic).
        # Threshold 1e-3 sits above the decay scale and far below learning scale.
        gate["expected"] = ("RGB state unchanged; aux params at momentum-amplified "
                            "weight-decay scale only (global_rel_l2 < 1e-3); proj weight "
                            "EXACTLY 0; proj bias may move")
        gate["passed"] = bool(gate["rgb_backbone_unchanged"]
                              and gate["aux_encoder_global_rel_l2"] < 1e-3
                              and max(gate["proj_weight_norms"]) == 0.0)
    else:
        # Reviewer ruling (2026-08-16): unify the active-aux threshold with the C0
        # control's < 1e-3.  > 1e-5 would call a 5e-5 model "learned" even though it
        # sits BELOW the measured control decay scale (2.05e-4 global_rel_l2 on C0).
        gate["expected"] = ("RGB state unchanged; aux params learned beyond the "
                            "measured control decay scale (global_rel_l2 > 1e-3); "
                            "proj P3/P4/P5 weight > 0")
        gate["passed"] = bool(gate["rgb_backbone_unchanged"]
                              and gate["aux_encoder_global_rel_l2"] > 1e-3
                              and min(gate["proj_weight_norms"]) > 0.0)
    (run_dir / "step4_update_gate.json").write_text(
        json.dumps(gate, indent=2, ensure_ascii=False), encoding="utf-8")
    if not gate["passed"]:
        raise RuntimeError(f"G6_REAL_UPDATE_GATE_FAIL: {gate}")
    print(f"[{a.group}] G6 real-update gate PASS: {gate['proj_weight_norms']}")
    print(f"[{a.group}] DONE -> {run_dir}")


if __name__ == "__main__":
    main()
