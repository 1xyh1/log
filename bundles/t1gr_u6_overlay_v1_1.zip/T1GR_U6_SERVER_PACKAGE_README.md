# T1-U6 Server Package v1.1

v1.1 changes only the four-arm initialization-identity audit and its focused
regression test. It does not change model weights, dataset construction,
augmentation, optimizer, schedule, or evaluation rules.

This additive package runs a fresh physical-six-channel G0--G3 suite on the
already frozen 1504 TRAIN / 198 DEV split. It creates new `t1gr_u6_*` reports
and run directories; it does not overwrite the legacy G suite or open the 298
FINAL HOLDOUT images.

## Required private inputs

1. existing `t1gr_g_view/view_manifest.json` and its complete RGB/IR view;
2. the exact frozen formal training ZIP referenced by E5-v2;
3. the exact `yolo26s.pt` checkpoint referenced by E5-v2;
4. the private DEV leakage-component map used by the existing LOFO evaluator.

Do not re-split or re-encode the dataset. The builder verifies the existing G
view and extracts only TRAIN/DEV Depth sidecars from the pinned ZIP.

## Three-GPU Linux workflow

Run from the repository root in the exact E5-v2 Python environment. Use three
identical GPUs; each lane exposes one GPU and keeps all four arms for one seed
on that device.

```bash
python scripts/t1gr_u6_build_view.py \
  --g-view-manifest /data/t1gr_g_view/view_manifest.json \
  --formal-zip /data/formal_2000.zip \
  --out-root /data/t1gr_u6_view

CUDA_VISIBLE_DEVICES=0 python scripts/t1gr_u6_server_preflight.py \
  --u6-view-manifest /data/t1gr_u6_view/u6_view_manifest.private.json \
  --base-checkpoint /data/yolo26s.pt

python scripts/t1gr_u6_server_parallel.py \
  --mode smoke --devices 0,1,2 \
  --u6-view-manifest /data/t1gr_u6_view/u6_view_manifest.private.json \
  --base-checkpoint /data/yolo26s.pt \
  --run-root /data/t1gr_u6_runs

python scripts/t1gr_u6_server_smoke_audit.py

python scripts/t1gr_u6_server_parallel.py \
  --mode formal --devices 0,1,2 \
  --u6-view-manifest /data/t1gr_u6_view/u6_view_manifest.private.json \
  --base-checkpoint /data/yolo26s.pt \
  --run-root /data/t1gr_u6_runs

CUDA_VISIBLE_DEVICES=0 python scripts/t1gr_u6_server_eval.py \
  --u6-view-manifest /data/t1gr_u6_view/u6_view_manifest.private.json \
  --dev-component-map /data/dev_component_map.private.json \
  --run-root /data/t1gr_u6_runs

python scripts/t1gr_u6_server_summarize.py
```

The evaluator performs 90 small DEV validation passes: native and common-input
conditions, the wrong-IR diagnostic, five LOFO views for deployable candidates,
and Depth-domain diagnostics. Training remains the expensive stage.

## One-GPU or partial-lane workflow

Run one complete seed lane at a time:

```bash
python scripts/t1gr_u6_server_run_lane.py \
  --mode smoke --seed 20260812 --device 0 \
  --u6-view-manifest /data/t1gr_u6_view/u6_view_manifest.private.json \
  --base-checkpoint /data/yolo26s.pt \
  --run-root /data/t1gr_u6_runs
```

Repeat for all three seeds, run the smoke audit, then repeat in `formal` mode.
The parallel launcher also accepts a seed subset, for example
`--seeds 20260812,20260813 --devices 0,1`.

Completed public reports plus matching `last.pt` files are reused
idempotently. A failed or interrupted run directory is deliberately retained
and blocks silent overwrite. Inspect its `E5_PRIVATE_FAILURE.json`, archive or
rename that exact run directory, and rerun the same lane; already completed
arms are reused.

Do not launch two lanes on one physical GPU merely as CPU threads. Use one lane
per GPU unless you have independently verified memory and timing isolation.

## Gates and interpretation

1. View builder: reuses the split, validates both Depth storage domains, and
   writes `t1gr_u6_view_public.json`.
2. Preflight: proves E5-v2 zero-aux equivalence, same-seed four-arm initial
   state identity, G2 derangement, matched visible augmentation, and Depth
   quarantine/geometry.
3. Twelve one-epoch smokes and audit: only a complete PASS authorizes formal
   training.
4. Twelve 80-epoch runs: MuSGD and the E5-v2 recipe remain frozen.
5. DEV evaluation and summary: recommends G3-D, G1-P, or G0-N under the frozen
   operational rule and emits a warning if the G2 wrong-IR control dominates.

The old P5 `G3-FE` is intentionally absent because it cannot be represented by
pure six-channel early fusion without changing its scientific question. Here
`G3-D` is the tri-modal Depth arm. All conclusions remain DEV-only; this
package never authorizes FINAL HOLDOUT access or production use.
