# T1-U6 Code and Design Audit (v1.1)

v1.1 fixes the preflight identity reducer so every G1/G2/G3 identity field is
compared with the same-seed G0 reference. A focused regression mutates the G3
complete-state hash and requires a hard failure. Model construction, data
processing, experiment design, and training arguments are unchanged.

Audit target: repository head `e55b28d` plus the prior D6 and legacy G3 server
overlays. This report records review findings; it is not a GPU-runtime PASS.

## History findings

- `643d281` contains a real historical six-channel early-fusion path.
- the later Step4 T-series intentionally changed the research mechanism to a
  separate auxiliary encoder with P5-only injection; it was not merely a
  refactor of the old early-fusion model.
- E5-v2 at `6f14392` is the only formal RGB mother baseline. Reusing the old
  small-data/R3 checkpoint or optimizer profile would be invalid.
- the legacy G design at `3b0a304` and implementation at `0926521` freeze a
  four-channel P5 mechanism and zero-IR DEV question. Their reports remain
  historical evidence and are not overwritten by U6.

U6 G0 is an architecture-matched physical-six-channel RGB control. It is
zero-aux equivalent at initialization, but it must not be advertised as a
bitwise rerun of the three-channel E5-v2 training trajectory: convolution
shape and backend kernel selection can change floating-point execution. E5-v2
remains the historical mother baseline; within-suite conclusions use U6 G0.

The outside recommendation that six-channel input is a proven project asset is
partly correct: the channel semantics and RGB-equivalent initialization are
valuable. Its claim of an uninterrupted six-channel mainline is too strong;
Step4 deliberately changed topology. U6 is therefore named as a new E5-v2
descendant rather than presented as the same implementation.

## Legacy G3 ruling

The old `G3-FE` freezes a separately identifiable auxiliary encoder while a
fusion projection remains trainable. Pure early fusion has only a first-conv
IR weight slice. Freezing that slice at its required zero initialization makes
IR computationally irrelevant and duplicates G0; making it nonzero breaks the
RGB-equivalent initial state. The old experiment cannot be merged honestly.

This package assigns the unambiguous new ID `G3-D` to paired IR plus qualified
Depth and mask. The legacy G3-FE overlay remains a separate P5 experiment and
must not be compared as if it shared the U6 architecture.

## D6 review

Correct and retained:

- physical six-channel E5-v2 end-to-end model;
- `[W_RGB,0,0,0]` stem initialization and full-detector zero-aux check;
- MuSGD / 80 epochs / batch 4 / 640 / last-primary recipe;
- `uint16 PNG` metric-depth qualification and fixed log normalization;
- unknown-scale JPG quarantine instead of fictitious millimetres;
- validity-aware resize/warp, nearest binary mask, shared geometry, and
  visible-only photometric augmentation;
- private failure traceback, content hashes, smoke authorization, and sealed
  FINAL HOLDOUT.

Corrections or extensions in U6:

1. D6's two arms map exactly to U6 G1-P and G3-D, so running both suites would
   duplicate six formal jobs. U6 supersedes D6 for the new server run.
2. D6 decoded Depth even in its zero-Depth control. U6 verifies every sidecar
   byte first, then skips Depth decode for G0/G1/G2; G0 also skips IR I/O.
3. U6 records and validates both IR donor identity and Depth/mask behavior in
   every training epoch.
4. all four same-seed initial-state hashes are checked, not only a two-arm
   pair.
5. the server runner hard-enforces each seed lane's frozen predecessor order,
   while retaining idempotent completed-run reuse.
6. the 3x4 schedule is disclosed as an incomplete Latin rectangle; it is not
   falsely described as completely position-balanced.
7. evaluation separates native deployment input, RGB-only common input,
   paired-IR/zero-Depth input, and wrong-IR input. This prevents an apparent
   training regularization effect from being called direct modality use.
8. G0/G1/G3 receive five LOFO views; G1/G3 receive both Depth storage-domain
   diagnostics. The frozen evaluator expects 90 validation passes.

## Static validation completed here

- all U6 Python files parse and compile;
- 20 U6 contract/selector/static tests pass;
- 28 unchanged legacy G design and implementation tests pass;
- the U6 source closure contains no legacy G implementation file and all
  frozen files receive SHA-256 commitments;
- positive, IR-fallback, RGB-fallback, and wrong-control-warning selector cases
  are tested, including the public-report safety scanner.

## Runtime boundary still open

This review environment does not contain PyTorch, OpenCV, Ultralytics 8.4.56,
the private TRAIN/DEV view, the formal ZIP, or the pinned checkpoint. Therefore
no claim is made that a real six-channel GPU batch or one-epoch smoke ran here.
The server must execute, in order:

1. view builder;
2. one-visible-GPU preflight;
3. all twelve one-epoch smokes;
4. smoke audit;
5. all twelve formal runs;
6. DEV evaluator and summarizer.

Any preflight or smoke failure blocks formal authorization. Unknown-scale JPG
Depth remains intentionally unused, heterogeneous GPUs are blocked by the
environment pin, and all conclusions remain DEV-only. FINAL HOLDOUT access is
not authorized.
