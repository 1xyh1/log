# T1-GR G Implementation + Smoke/Formal Runner Bundle v1

This is the additive implementation stage after design-freeze commit
`3b0a304`. Copy the bundle into the repository root. It intentionally replaces
the design-stage `scripts/t1gr_g_train_entry.py` blocker with a suite-only
entry; it does not modify the frozen design, E5 v2 evidence, scanner, E4 split,
or any FINAL HOLDOUT artifact.

## Frozen decisions retained

| Item | Effective value |
|---|---|
| Mother baseline | E5 v2, DEV mAP50-95 `0.3519127675021732` |
| Optimizer | explicit `MuSGD` |
| Training | 80 epochs, batch 4, nbs 64, 640 px |
| Optimizer hyperparameters | lr0 0.01, momentum 0.9, weight decay 0.0005 |
| Arms | G0-N NULL, G1-P paired IR, G2-S balanced fully-wrong IR |
| Seeds | 20260812, 20260813, 20260814 |
| Primary checkpoint | `last.pt`; `best.pt` is diagnostic only |
| Primary evaluation | ZERO-IR DEV, max_det 100, full + five E3-component LOFO |
| Claim | auditable initialization only; no numerical-repeatability claim |
| FINAL HOLDOUT | sealed and not accepted by any CLI |

The input is one four-channel array: visible BGR plus selected grayscale IR.
The model converts the auxiliary input to `[IR, zero depth]`; depth is not used.
Each top-level augmentation stream is keyed by seed, zero-based epoch, and
recipient ID. Mosaic/affine/resize/pad/flip operate on the combined array.
Albumentations and HSV operate on the visible three channels only.

## Runtime compatibility revision (2026-08-21)

This package includes the two fixes found by the first target-machine
preflight: Ultralytics-patched grayscale reads shaped `H x W x 1` are squeezed
losslessly before four-channel concatenation (ordinary three-channel IR is
converted with OpenCV BGR-to-gray), and the stock `DetectionModel.nc` value is
bound before constructing `T1GRP5Model`. Both failure modes have dedicated
regression tests.

## Apply and test

From the repository root:

```powershell
Copy-Item -Recurse -Force <bundle>\* .
.venv\Scripts\python.exe -m unittest discover -s tests -p "test_t1gr_g*.py" -v
```

The module-form command `-m unittest tests.test_t1gr_g_implementation` still
requires `tests/__init__.py`; discovery does not.

## 1. Build the private TRAIN/DEV multimodal view

Both the view and all suite state/run directories must be outside the Git
repository.

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_build_multimodal_view.py `
  --train-dev-access <E4_TRAIN_DEV_ACCESS_PRIVATE.json> `
  --formal-zip <pinned_formal_zip> `
  --out-root E:\google\t1gr_g_view
```

The view contains only TRAIN 1504 and DEV 198 visible/IR/label members. It does
not copy depth and never materializes the 298 FINAL HOLDOUT IDs.

## 2. Run implementation preflight

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_implementation_preflight.py `
  --view-manifest E:\google\t1gr_g_view\view_manifest.json `
  --base-checkpoint <pinned_E5_base_checkpoint>
```

Preflight verifies:

- E5 v2/design/spec/checkpoint/environment provenance;
- stock E5 visible-tensor and label parity under identical recipient draws;
- same-seed visible/label identity across G0/G1/G2;
- G2 changes only donor IR identity before shared geometry;
- identical complete initial model state, keys and trainability map within seed;
- four-channel model contract, end-to-end head and E2E loss;
- implementation source hashes.

Only a passing preflight sets `smoke_training_authorized=true`.

## 3. Run all nine one-epoch smoke runs

Use a fresh private state file. The orchestrator enforces the frozen Latin
square and resumes only from the next incomplete position.

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_run_smoke_suite.py `
  --view-manifest E:\google\t1gr_g_view\view_manifest.json `
  --base-checkpoint <pinned_E5_base_checkpoint> `
  --run-root E:\google\t1gr_g_runs `
  --suite-state E:\google\t1gr_g_smoke_suite.private.json
```

Each run records private recipient/donor JSONL and optimizer membership, while
the public report contains commitments only. At every epoch boundary the old
8-worker iterator is synchronously shut down before a fresh iterator is
created, so a prefetched G2 mapping cannot cross epochs. DEV validation uses 16
workers and ZERO IR.

If a run fails, its directory is retained with `E5_PRIVATE_FAILURE.json` and no
PASS report is issued. Archive that incomplete directory explicitly before
retrying the same suite position. Do not delete or rerun already completed
positions to select outcomes.

## 4. Authorize formal execution

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_smoke_audit.py
```

The audit requires 9/9 reports, exact order, one completed epoch each, complete
source traces, MuSGD optimizer-group identity, same-seed initialization/start
state identity, exact worker counts, and unchanged implementation hashes. Only
this audit may set `multiseed_training_authorized=true`; FINAL HOLDOUT remains
false.

## 5. Run the formal 9 × 80-epoch suite

Use a different state file from smoke:

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_run_formal_suite.py `
  --view-manifest E:\google\t1gr_g_view\view_manifest.json `
  --base-checkpoint <pinned_E5_base_checkpoint> `
  --run-root E:\google\t1gr_g_runs `
  --suite-state E:\google\t1gr_g_formal_suite.private.json
```

The compatibility entry below is equivalent and still suite-only:

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_train_entry.py --mode formal `
  --view-manifest E:\google\t1gr_g_view\view_manifest.json `
  --base-checkpoint <pinned_E5_base_checkpoint> `
  --run-root E:\google\t1gr_g_runs `
  --suite-state E:\google\t1gr_g_formal_suite.private.json
```

There is no supported single-arm or single-seed formal CLI.

## 6. Evaluate last.pt on DEV

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_eval_suite.py `
  --view-manifest E:\google\t1gr_g_view\view_manifest.json `
  --dev-component-map <E3_DEV_COMPONENT_MAP_PRIVATE.json> `
  --run-root E:\google\t1gr_g_runs
```

This produces:

- `reports/step4_t1gr/per_seed_results.json`;
- `reports/step4_t1gr/t1gr_g_eval_public.json`.

It evaluates nine `last.pt` checkpoints on full ZERO-IR DEV plus five
component-preserving LOFO subsets. It accepts no FINAL HOLDOUT input.

Then use the already-frozen design summarizer:

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_summarize.py `
  --design config\t1gr_g_design.frozen.json `
  --results reports\step4_t1gr\per_seed_results.json `
  --cross-seed-out reports\step4_t1gr\cross_seed_summary.json `
  --summary-out reports\step4_t1gr\t1gr_summary.json
```

No positive DEV result in this chain authorizes opening FINAL HOLDOUT.
