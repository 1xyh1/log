# T1-GR G0/G1/G2 Design-Freeze Bundle v1

This bundle is the additive next stage after the accepted E5 v2 RGB baseline.
It freezes the matched three-arm, three-seed experiment and provides pure,
testable code for schedule generation, design auditing, run planning, seeded
model construction, and DEV-only adjudication.

It deliberately does **not** start training.  The accepted E5 v2 audit says:

```text
t1gr_design_entry_authorized       = true
t1gr_multiseed_training_authorized = false
final_holdout_open_authorized      = false
```

The code enforces those boundaries.  A passing design audit authorizes only the
implementation/preflight stage.  Formal nine-run execution remains blocked
until a later implementation-and-smoke audit explicitly authorizes it.

## Frozen experiment

| Arm | Training-time IR source | Model treatment |
|---|---|---|
| `G0-N` | recipient-paired IR is loaded only for matched aux-buffer exposure; detection path is NULL | `T0-N` |
| `G1-P` | correctly paired recipient IR | `T1-F` |
| `G2-S` | deterministic balanced fully-wrong donor IR | `T1-F` |

Seeds are frozen once: `20260812`, `20260813`, `20260814`.

The launch order is a 3x3 Latin square, so each arm appears once in each
position.  G2 uses a deterministic seed-keyed cyclic derangement.  Every epoch
is a bijection with zero self-matches and exactly one use of every donor.  With
1,504 TRAIN samples and 80 epochs, each recipient receives 80 distinct wrong
donors; the design does not falsely claim exhaustive balance over all 1,503
possible donors.

## What is inherited from E5 v2

- `YOLO26s`, physical `nc=12`, `end2end=true`
- pinned checkpoint and shape-compatible partial transfer policy
- 80 epochs, batch 4, `nbs=64`, image size 640
- explicit `MuSGD`, `lr0=0.01`, momentum `0.9`, weight decay `0.0005`
- E5 v2 augmentation, sampling, validation cadence, and checkpoint policy
- DEV evaluation at `conf=0.001`, `iou=0.7`, `max_det=100`
- `last.pt` is the primary checkpoint; `best.pt` is diagnostic only

The G model keeps the old audited P5-only direct-IR topology, but does **not**
reuse the obsolete small-data R3 optimizer profile.  RGB backbone trainability
is retained (`freeze_rgb_backbone=false`) so G0/G1/G2 remain descendants of the
formal E5 mother baseline.  All three arms must have identical model keys,
initial state, `requires_grad` map, and optimizer groups within each seed.

## Apply to the repository

Copy the bundle contents into the repository root without deleting or editing
the frozen E2-E5 artifacts.  The paths are additive.

Run the unit tests first:

```powershell
.venv\Scripts\python.exe -m unittest tests.test_t1gr_g -v
```

Run the private-data-free synthetic schedule/decision gate:

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_synthetic_gate.py `
  --design config\t1gr_g_design.frozen.json `
  --out reports\step4_t1gr\t1gr_g_synthetic_gate_public.json
```

Run the public design audit against the already-pushed E5 v2 reports:

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_design_audit.py `
  --design config\t1gr_g_design.frozen.json `
  --e5-recipe reports\step4_t1gr\e5_v2_step1_recipe_public.json `
  --e5-final reports\step4_t1gr\e5_v2_final_audit_public.json `
  --out reports\step4_t1gr\t1gr_g_design_audit_public.json
```

Generate the immutable nine-run plan:

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_make_run_plan.py `
  --design config\t1gr_g_design.frozen.json `
  --design-audit reports\step4_t1gr\t1gr_g_design_audit_public.json `
  --out reports\step4_t1gr\t1gr_g_run_plan_public.json
```

Expected result at this stage:

```text
design_freeze_passed              = true
implementation_entry_authorized  = true
multiseed_training_authorized     = false
final_holdout_open_authorized     = false
```

## Next implementation gate

Before formal training, the next patch must prove all of the following with a
one-epoch three-arm smoke for every frozen seed:

1. joint RGB/IR geometric augmentation is recipient-keyed and bitwise matched;
2. the E5 v2 visible-image augmentation distribution is preserved;
3. G2 changes only IR source identity and logs every recipient/donor pair;
4. each same-seed arm starts from the same complete model-state hash;
5. state-dict keys, trainability map, optimizer groups, and hyperparameters are
   identical across arms;
6. G0 cannot pass an auxiliary residual into the detection loss;
7. G1/G2 use the same P5 FULL mechanism;
8. no FINAL HOLDOUT identifier, member, path, label, or metric is available.

`scripts/t1gr_g_train_entry.py` is a deliberate fail-closed entry point.  It
will refuse both smoke and formal execution until the corresponding downstream
authorization artifact exists and is pinned.  It prevents old training code or
an ad-hoc command from silently becoming the formal experiment.

## DEV-only result schema

After an authorized implementation produces nine DEV evaluations, place the
rows in `reports/step4_t1gr/per_seed_results.json` using the schema documented
in `docs/step4_t1gr/DESIGN_FREEZE.md`.  Then run:

```powershell
.venv\Scripts\python.exe scripts\t1gr_g_summarize.py `
  --design config\t1gr_g_design.frozen.json `
  --results reports\step4_t1gr\per_seed_results.json `
  --cross-seed-out reports\step4_t1gr\cross_seed_summary.json `
  --summary-out reports\step4_t1gr\t1gr_summary.json
```

The summarizer never reads a dataset or checkpoint and rejects any input that
claims FINAL HOLDOUT access.  It cannot authorize opening FINAL HOLDOUT.
